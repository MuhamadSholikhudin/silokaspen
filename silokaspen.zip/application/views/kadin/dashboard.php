<div class="right_col" role="main" style="min-height: 4546px;">
    <div class>
        <div class="page-title">
            <div class="title_center">
                <h3>Selamat datang, <?= $this->session->userdata('namalengkap') ?> <small> Kepala Disdikpora</small></h3>
            </div>




        </div>


        <div class="clearfix"></div>

        <div class="row">

            <div class="col-sm-12">
                <br><br><br>
                <?php include "assets/gambar_pkl/beranda.txt" ?>
            </div>

        </div>


    </div>
</div>